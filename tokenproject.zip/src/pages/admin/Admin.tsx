import React from "react"


interface SelectedProps {

}

const Selected: React.FC<SelectedProps> = () => {
    return <div>
        admin
    </div>
}

export default Selected;

