import React from "react"


interface HomeProps {

}

const Home: React.FC<HomeProps> = () => {
    return <div>
        home
    </div>
}

export default Home;

