import LoginForm from "../../components/forms/loginForm/LoginForm"

interface LoginProps {

}

const Login: React.FC<LoginProps> = () => {
    return <div>
        <LoginForm />
    </div>
}

export default Login