import React from "react"


interface SelectedProps {

}

const Selected: React.FC<SelectedProps> = () => {
    return <div>
        
    </div>
}

export default Selected;

