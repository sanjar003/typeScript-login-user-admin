import React from "react"


interface SelectedProps {

}

const Selected: React.FC<SelectedProps> = () => {
    return <div>
        selected
    </div>
}

export default Selected;

