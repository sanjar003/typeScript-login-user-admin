import { useState } from "react"
import Input from "../../customInput/CustomInput"
import { Link } from "react-router-dom"
import Button, { ButtonProps } from "../../customButton/CustomButton"

const LoginForm: React.FC = () => {
    const [email, setEmail] = useState("")
    const [password, setPassword] = useState("")


    const handleGetEmail = (value: string) => {
        setEmail(value)
    }

    const handleGetPassword = (value: string) => {
        setPassword(value)
    }

    const loginButtonProps: ButtonProps = {
        type: "submit",
        variant: "primary",
        color: "blue",
        width: "300px"
    };

    return (
        <form >
            <h3>Вход</h3>
            <Input type="email" label="Email" placeholder="Введите сообщение" value={email} onChange={handleGetEmail} width="300px" />
            <Input type="password" label="Password" placeholder="Введите пароль" value={password} onChange={handleGetPassword} width="300px" />
            <Link to="/registration">Нет аккаунта, зарегистрируйтесь</Link>
            <div>
                <Button {...loginButtonProps}>Войти</Button>
            </div>

        </form>
    )
}

export default LoginForm